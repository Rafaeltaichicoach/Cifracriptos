import { useState } from 'react'
import Buscador from './components/Buscador.jsx'
import MiApi from './components/MiApi.jsx'
import './App.css'

function App() {
  const [searchTerm, setSearchTerm] = useState('')

  return (
    <main className="site-shell">
      <header className="topbar">
        <a className="brand" href="#inicio" aria-label="Cifra, inicio">
          <span className="brand-mark" aria-hidden="true">C</span>
          <span>cifra<span className="brand-period">.</span></span>
        </a>
        <nav className="main-nav" aria-label="Navegación principal">
          <a className="nav-active" href="#mercado">Mercado</a>
          <a href="#mercado">Criptomonedas</a>
        </nav>
        <a className="topbar-link" href="https://coinmarketcap.com/api/documentation/v1/" target="_blank" rel="noreferrer">
          Datos de CoinMarketCap <span aria-hidden="true">↗</span>
        </a>
      </header>

      <section className="intro" id="inicio">
        <div className="intro-copy">
          <p className="eyebrow"><span className="live-dot" /> DATOS DEL MERCADO EN VIVO</p>
          <h1>El mercado cripto,<br /><span>sin ruido.</span></h1>
          <p className="intro-description">
            Sigue precios y movimientos de las principales criptomonedas en un solo lugar.
          </p>
        </div>
        <div className="market-note" aria-label="Mercado global">
          <span className="note-label">MERCADO GLOBAL</span>
          <span className="note-value">24<span>h</span></span>
          <span className="note-caption">Una mirada rápida a los activos digitales</span>
          <span className="note-line" aria-hidden="true" />
        </div>
      </section>

      <section className="market-section" id="mercado" aria-labelledby="market-heading">
        <div className="section-heading">
          <div>
            <p className="eyebrow section-kicker">EXPLORADOR DE ACTIVOS</p>
            <h2 id="market-heading">Mercado de criptomonedas</h2>
          </div>
          <Buscador value={searchTerm} onChange={setSearchTerm} />
        </div>
        <MiApi searchTerm={searchTerm} />
      </section>

      <footer className="site-footer">
        <a className="brand footer-brand" href="#inicio">
          <span className="brand-mark" aria-hidden="true">C</span>
          <span>cifra<span className="brand-period">.</span></span>
        </a>
        <p>Información de mercado proporcionada por CoinMarketCap.</p>
        <a href="https://coinmarketcap.com/" target="_blank" rel="noreferrer">CoinMarketCap ↗</a>
      </footer>
    </main>
  )
}

export default App
