function Buscador({ value, onChange }) {
  return (
    <form className="search-form" role="search" onSubmit={(event) => event.preventDefault()}>
      <label className="search-box">
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <circle cx="10.8" cy="10.8" r="6.8" />
          <path d="m16 16 4.2 4.2" />
        </svg>
        <span className="visually-hidden">Buscar criptomoneda por nombre o símbolo</span>
        <input
          type="search"
          value={value}
          onChange={(event) => onChange(event.target.value)}
          placeholder="Buscar activo..."
        />
        {value && (
          <button className="clear-search" type="button" onClick={() => onChange('')} aria-label="Limpiar búsqueda">
            ×
          </button>
        )}
      </label>
    </form>
  )
}

export default Buscador