import { useEffect, useState } from 'react'

const currencyFormatter = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
  maximumFractionDigits: 2,
})

const numberFormatter = new Intl.NumberFormat('en-US', {
  maximumFractionDigits: 2,
})

function formatPrice(value) {
  if (!Number.isFinite(value)) return '—'
  if (value > 0 && value < 0.01) return `$${value.toPrecision(4)}`
  return currencyFormatter.format(value)
}

function MiApi({ searchTerm }) {
  const [assets, setAssets] = useState([])
  const [status, setStatus] = useState('loading')
  const [errorMessage, setErrorMessage] = useState('')
  const [updatedAt, setUpdatedAt] = useState(null)

  useEffect(() => {
    const controller = new AbortController()

    async function loadAssets() {
      try {
        const response = await fetch('/api/cryptocurrencies?limit=100&convert=USD', {
          signal: controller.signal,
        })
        const payload = await response.json()

        if (!response.ok) {
          throw new Error(payload.status?.error_message || 'No se pudieron cargar los datos del mercado.')
        }

        setAssets(payload.data || [])
        setUpdatedAt(new Date())
        setStatus('success')
      } catch (error) {
        if (error.name === 'AbortError') return
        setErrorMessage(error.message || 'Ocurrió un error al conectar con CoinMarketCap.')
        setStatus('error')
      }
    }

    loadAssets()
    return () => controller.abort()
  }, [])

  const normalizedSearch = searchTerm.trim().toLocaleLowerCase()
  const filteredAssets = assets.filter((asset) => (
    asset.name.toLocaleLowerCase().includes(normalizedSearch)
    || asset.symbol.toLocaleLowerCase().includes(normalizedSearch)
  ))
  const positiveAssets = assets.filter((asset) => asset.quote?.USD?.percent_change_24h > 0).length

  return (
    <div className="market-board">
      <div className="market-summary" aria-live="polite">
        <div className="summary-item">
          <span className="summary-label">ACTIVOS LISTADOS</span>
          <strong>{status === 'success' ? numberFormatter.format(assets.length) : '—'}</strong>
        </div>
        <div className="summary-item">
          <span className="summary-label">EN VERDE · 24 H</span>
          <strong>{status === 'success' ? numberFormatter.format(positiveAssets) : '—'}</strong>
        </div>
        <div className="summary-updated">
          <span className="status-indicator" />
          {updatedAt ? `Actualizado ${updatedAt.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}` : 'Conectando con el mercado'}
        </div>
      </div>

      <div className="table-wrap">
        <table className="asset-table">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Activo</th>
              <th scope="col">Precio</th>
              <th scope="col">Cambio · 24 h</th>
              <th scope="col">Capitalización</th>
              <th scope="col">Volumen · 24 h</th>
            </tr>
          </thead>
          {status === 'success' && (
            <tbody>
              {filteredAssets.map((asset) => {
                const quote = asset.quote?.USD || {}
                const change = quote.percent_change_24h
                const isPositive = change >= 0

                return (
                  <tr key={asset.id}>
                    <td className="rank-cell">{asset.cmc_rank}</td>
                    <td>
                      <div className="asset-name">
                        <span className="asset-monogram" aria-hidden="true">{asset.symbol.slice(0, 1)}</span>
                        <span className="asset-titles">
                          <strong>{asset.name}</strong>
                          <span>{asset.symbol}</span>
                        </span>
                      </div>
                    </td>
                    <td className="numeric-cell price-cell">{formatPrice(quote.price)}</td>
                    <td>
                      <span className={`change-pill ${isPositive ? 'change-positive' : 'change-negative'}`}>
                        {isPositive ? '+' : ''}{Number(change).toFixed(2)}%
                      </span>
                    </td>
                    <td className="numeric-cell">{formatPrice(quote.market_cap)}</td>
                    <td className="numeric-cell">{formatPrice(quote.volume_24h)}</td>
                  </tr>
                )
              })}
            </tbody>
          )}
        </table>

        {status === 'loading' && (
          <div className="table-message" role="status">
            <span className="loader" />
            <p>Cargando cotizaciones...</p>
          </div>
        )}
        {status === 'error' && (
          <div className="table-message error-message" role="alert">
            <span className="message-symbol">!</span>
            <p>{errorMessage}</p>
            <span className="message-hint">Añade CMC_API_KEY a tu archivo .env.local y reinicia Vite.</span>
          </div>
        )}
        {status === 'success' && filteredAssets.length === 0 && (
          <div className="table-message">
            <p>No encontramos activos para “{searchTerm}”. Prueba con otro nombre o símbolo.</p>
          </div>
        )}
      </div>
      <p className="data-note">Los precios pueden cambiar rápidamente. Datos en USD proporcionados por CoinMarketCap.</p>
    </div>
  )
}

export default MiApi