# Cifra

Landing de mercado de criptomonedas creada con React y Vite. Muestra cotizaciones en USD desde CoinMarketCap y permite filtrar por nombre o símbolo.

## Estructura

```text
src/
  components/
    Buscador.jsx   # Entrada de búsqueda; recibe value y onChange por props
    MiApi.jsx      # Consulta la API, filtra activos y muestra estados y resultados
  App.jsx          # Landing y estado compartido de búsqueda
  App.css          # Estilos de la landing y la tabla
  index.css        # Estilos globales y variables de diseño
vite.config.js     # Proxy local; adjunta la API key en el servidor
```

## Configurar CoinMarketCap

1. Crea una API key desde el [panel de CoinMarketCap](https://coinmarketcap.com/api/).
2. Crea `.env.local` en la carpeta que contiene la carpeta del proyecto `criptos`.
3. Añade tu key así, sin comillas:

   ```env
   CMC_API_KEY=tu_api_key
   ```

4. Ejecuta `npm run dev`. Si Vite ya estaba abierto, detenlo y vuelve a iniciarlo para que lea la variable.

No pegues la key en componentes React ni uses el prefijo `VITE_`: las variables del cliente pueden quedar visibles en el navegador. `.env.local` está excluido por Git y Vite lo lee desde la carpeta superior del proyecto.

## Ejecutar

```bash
npm install
npm run dev
```

Para revisar el resultado de producción, ejecuta `npm run build`.

El proxy de CoinMarketCap está habilitado por el middleware del servidor de desarrollo de Vite. Para publicar la aplicación, configura una función backend o serverless equivalente en el hosting; no expongas la key en el frontend.

## Flujo de props

`App` mantiene `searchTerm` y pasa su valor y actualizador a `Buscador` como `value` y `onChange`. También pasa `searchTerm` a `MiApi`. Este último obtiene hasta 100 activos del endpoint `/api/cryptocurrencies`, filtra la lista y presenta la cotización, la variación de 24 horas, la capitalización y el volumen.# React + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react) uses [Oxc](https://oxc.rs)
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react-swc) uses [SWC](https://swc.rs/)

## React Compiler

The React Compiler is not enabled on this template because of its impact on dev & build performances. To add it, see [this documentation](https://react.dev/learn/react-compiler/installation).

## Expanding the ESLint configuration

If you are developing a production application, we recommend using TypeScript with type-aware lint rules enabled. Check out the [TS template](https://github.com/vitejs/vite/tree/main/packages/create-vite/template-react-ts) for information on how to integrate TypeScript and [`typescript-eslint`](https://typescript-eslint.io) in your project.
