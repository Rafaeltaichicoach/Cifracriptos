import react from '@vitejs/plugin-react'
import { defineConfig, loadEnv } from 'vite'
import { fileURLToPath } from 'node:url'

function coinMarketCapProxy(apiKey) {
  return {
    name: 'coinmarketcap-api-proxy',
    configureServer(server) {
      server.middlewares.use('/api/cryptocurrencies', async (request, response) => {
        if (!apiKey) {
          response.statusCode = 503
          response.setHeader('Content-Type', 'application/json')
          response.end(JSON.stringify({
            status: { error_message: 'Falta configurar CMC_API_KEY en .env.local.' },
          }))
          return
        }

        const query = new URL(request.url, 'http://localhost').searchParams
        const requestedLimit = Number.parseInt(query.get('limit') || '100', 10)
        const limit = Math.min(Math.max(requestedLimit || 100, 1), 100)
        const upstreamUrl = new URL('https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/latest')
        upstreamUrl.searchParams.set('limit', String(limit))
        upstreamUrl.searchParams.set('convert', 'USD')

        try {
          const upstreamResponse = await fetch(upstreamUrl, {
            headers: { 'X-CMC_PRO_API_KEY': apiKey, Accept: 'application/json' },
          })
          response.statusCode = upstreamResponse.status
          response.setHeader('Content-Type', 'application/json')
          response.end(await upstreamResponse.text())
        } catch {
          response.statusCode = 502
          response.setHeader('Content-Type', 'application/json')
          response.end(JSON.stringify({
            status: { error_message: 'No fue posible conectar con CoinMarketCap.' },
          }))
        }
      })
    },
  }
}

export default defineConfig(({ mode }) => {
  const envDirectory = fileURLToPath(new URL('..', import.meta.url))
  const env = loadEnv(mode, envDirectory, '')

  return {
    plugins: [react(), coinMarketCapProxy(env.CMC_API_KEY)],
  }
})
